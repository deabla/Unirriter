package app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CadastroPratos {

	int qntPrato;
	Prato pratoUm = new Prato();
	Scanner sc = new Scanner(System.in);

	public void CadastrarPratos() {

		System.out.println("|Quantos pratos voce quer cadastrar?              |");
		qntPrato = sc.nextInt();

		for (int i = 0; i < qntPrato; i++) {
			System.out.println("| Digite o nome prato:             	          |");
			sc.nextLine();
			pratoUm.setNome(sc.nextLine());

			System.out.println("| Digite a descricao do prato:        		  |");
			pratoUm.setDescricao(sc.nextLine());

			// do while para delimitar o preço
			do {
				System.out.println("| Digite o valor do prato:       		  |");
				pratoUm.setPreco(sc.nextDouble());
				if (pratoUm.getPreco() <= 0) {
					System.out.println("Erro! Valor inválido");
				}
			} while (pratoUm.getPreco() <= 0);

		}
	}
	
	public void MostrarPratos() {
		
		for (int i = 0; i < qntPrato; i++){
			System.out.println("Prato " + i);
			System.out.println("nome: " + pratoUm.getNome());
			System.out.println("Descricao: " + pratoUm.getDescricao());
			System.out.println("Valor: R$ " + pratoUm.getPreco());
		}
	}
}
