package app;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CadastroUsuario {
	
	Scanner scu = new Scanner(System.in);
	Usuario user1 = new Usuario();
	int qntUser;
	
	public void cadastrarUsuario() {
		
		
		System.out.println("|Quantos usuarios voce quer cadastrar?|");
		qntUser = scu.nextInt();
		
		for (int i = 0; i < qntUser; i++) {
		System.out.println("| Digite seu nome:                    |");
		scu.nextLine();
		user1.setNome(scu.nextLine());

		System.out.println("| Digite seu E-mail:                  |");
		user1.setEmail(scu.nextLine());

		do {
			System.out.println("| Digite seu CPF:                 |");
			user1.setCpf(scu.nextLine());
			if (user1.getCpf().length() < 11 || user1.getCpf().length() > 11) {
				System.out.println("ERRO! CPF INVALIDO!");
			}
		} while (user1.getCpf().length() < 11 || user1.getCpf().length() > 11);

		System.out.println("| Digite seu Endereco:                |");
		user1.setEndereco(scu.nextLine());

		do {
			System.out.println("| Digite seu numero de telefone:  |");
			user1.setTelefone(scu.nextLine());
			if (user1.getTelefone().length() < 9) {
				System.out.println("ERRO! CPF INVÁLIDO!");
			}
		} while (user1.getTelefone().length() < 9);
		System.out.println("\n");
		}
	}
	
	int i = 0;	
	public void mostrarUsuarios() {
		
		for (int i = 0; i < qntUser; i++){
			System.out.println("Usuario " + i);
			System.out.println("Nome: " + user1.getNome());
			System.out.println("E-mail: " +  user1.getEmail());
			System.out.println("CPF: " + user1.getCpf());
			System.out.println("Endereco: " + user1.getEndereco());
			System.out.println("Telefone: " + user1.getTelefone());
			System.out.println("\n");
		}
	}
	
	//salvar em arquivo .txt
		public String salvar() {
			
			try {
				FileWriter fw = new FileWriter("Usuarios.txt");
				PrintWriter pw = new PrintWriter(fw);
				pw.println("Nome: "+ user1.getNome());
				pw.println("E-mail "+ user1.getEmail());
				pw.println("CPF: "+ user1.getCpf());
				pw.println("Endereco: "+ user1.getEndereco());
				pw.println("Telefone: "+ user1.getTelefone());
			} catch (IOException ex) {
				Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
			}
			return null;
		}
}
