package app;

import java.util.Scanner;

public class AcessoUsuario {

	public void MenuDoUsuario() {

		MenuAcessos menu = new MenuAcessos();
		Scanner scUser = new Scanner(System.in);
		CadastroUsuario cu = new CadastroUsuario();

		int opcao2;

		do {

			System.out.println(" __________________________________________");
			System.out.println("|            Sistema de Usuario            |");
			System.out.println("|__________________________________________|");
			System.out.println("|                                          |");
			System.out.println("| 1- Cadastrar				               |");
			System.out.println("| 2- Login			          		       |");
			System.out.println("| 3- Voltar pro Menu Principal			   |");
			System.out.println("| 0- Sair                                  |");
			System.out.println("|__________________________________________|");
			System.out.println("|         Digite a opcao desejada          |");
			opcao2 = scUser.nextInt();
			System.out.println("|__________________________________________|");

			switch (opcao2) {
			case 1:
				System.out.println(" _____________________________________");
				System.out.println("|        Cadastro de Usuario          |");
				System.out.println("|_____________________________________|");
				System.out.println("|                                     |");
				cu.cadastrarUsuario();
				System.out.println("| USUARIO CADASTRADO COM SUCESSO!     |");
				System.out.println("|_____________________________________|");
				break;

			case 2: // entrar cad feito / MAPS
				cu.mostrarUsuarios();
				break;

			case 3:
				menu.MenuPrincipal();
				break;

			case 0:
				System.out.println("Sistema Encerrado.");
				break;

			}
		} while (opcao2 != 0);
	}
}