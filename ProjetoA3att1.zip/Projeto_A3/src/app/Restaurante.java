package app;

public class Restaurante {
	
	//definindo atributos
	private String nomeRestaurante;
	private String endereco;
	private String horarioAbrir;
	private String horarioFechar;
	
	//encapsulamento
	public String getnomeRestaurante() {
		return nomeRestaurante;
	}
	public void setnomeRestaurante(String nomeRestaurante) {
		this.nomeRestaurante = nomeRestaurante;
	}
	
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public String getHorarioAbrir() {
		return horarioAbrir;
	}
	public void setHorarioAbrir(String horarioAbrir) {
		this.horarioAbrir = horarioAbrir;
	}

	public String getHorarioFechar() {
		return horarioFechar;
	}
	public void setHorarioFechar(String horarioFechar) {
		this.horarioFechar = horarioFechar;
	}
	@Override
	public String toString() {
		return "Restaurante \nRestaurante " + nomeRestaurante + "\nEndereco: " + endereco + "\nHorarios: " + horarioAbrir;
	}
	
	
}
