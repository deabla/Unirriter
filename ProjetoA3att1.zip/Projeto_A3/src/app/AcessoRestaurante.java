package app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class AcessoRestaurante {
	
	public void MenuRestaurante() {

		CadastroPratos cp = new CadastroPratos();
		MenuAcessos mn = new MenuAcessos();
		List <Restaurante> restaurante = new ArrayList<>();
		List <Prato> prato = new ArrayList<>();
		Scanner scres = new Scanner(System.in);

		int op;

		do {
			System.out.println(" __________________________________________");
			System.out.println("|            Sistema Restaurante           |");
			System.out.println("|__________________________________________|");
			System.out.println("|                                          |");
			System.out.println("| 1- Cadastrar Restaurante				   |");
			System.out.println("| 2- Login			          		       |");
			System.out.println("| 3- Voltar ao Menu principal              |");
			System.out.println("| 0- Sair                                  |");
			System.out.println("|__________________________________________|");
			System.out.println("|         Digite a opcao desejada          |");
			op = scres.nextInt();
			System.out.println("|__________________________________________|");

			switch (op) {
			case 1:
				Restaurante res1 = new Restaurante();
				

				System.out.println(" _________________________________________________");
				System.out.println("|        	Cadastro do Restaurante    		      |");
				System.out.println("|_________________________________________________|");
				System.out.println("|                                     	          |");
				System.out.println("| 		Digite o nome do restaurante:             |");
				scres.nextLine();
				res1.setnomeRestaurante(scres.nextLine());

				cp.CadastrarPratos();
				System.out.println("| Pratos cadastrados com sucesso!           |\n");

				System.out.println("| Agora digite o Endereco do seu estabelecimento: |");
				res1.setEndereco(scres.nextLine());

				System.out.println("| Digite os horario de abertura:                  |");
				res1.setHorarioAbrir(scres.nextLine());

				System.out.println("| Digite os horario de fechamento:                |");
				res1.setHorarioFechar(scres.nextLine());
				restaurante.add(res1);
				System.out.println("***RESTAURANTE CADASTRADO COM SUCESSO!!!***");
				break;

			case 2:
				//Login
				break;

			case 3:
				mn.MenuPrincipal();
				break;

			}
		} while (op != 0);
	}
}
