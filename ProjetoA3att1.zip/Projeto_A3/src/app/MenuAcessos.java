package app;

import java.util.Scanner;

// PROGRAMA PRINCIPAL (MAIN)
public class MenuAcessos {

	public static void main(String[] args) {

		MenuAcessos menu = new MenuAcessos();
		menu.MenuPrincipal();
	}
	
	public void MenuPrincipal() {
		AcessoUsuario au = new AcessoUsuario();
		AcessoRestaurante ar = new AcessoRestaurante();
		Scanner sc = new Scanner(System.in);

		// Atributo para escolher a opcao do menu
		int opcao;

		do {
			System.out.println(" _____________________________________");
			System.out.println("|         Vergoin da Profission       |");
			System.out.println("|_____________________________________|");
			System.out.println("|                                     |");
			System.out.println("|  1- Acesso Usuario                  |");
			System.out.println("|  2- Acesso Restaurante              |");
			System.out.println("|  0- Sair                            |");
			System.out.println("|_____________________________________|");
			System.out.println("|       Digite a opcao desejada       |");
			opcao = sc.nextInt();
			System.out.println("|_____________________________________|");

			switch (opcao) {

			case 1:
				au.MenuDoUsuario();
				break;
				
			case 2:
				ar.MenuRestaurante();
				break;
				
			case 0:
				System.out.println("Programa encerrado.");
				break;
				
			default:
				System.out.println("Opcao invalida");
			}
			

		} while (opcao != 0);
	}

}
