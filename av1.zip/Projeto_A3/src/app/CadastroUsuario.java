package app;

import java.util.Scanner;

public class CadastroUsuario {

	public void Cadastrar() {
		
		Scanner scCad = new Scanner(System.in);
		Usuario user = new Usuario();
		
		System.out.println("Nome: ");
		scCad.nextLine();
		user.setNome(scCad.nextLine());
		
		System.out.println("E-mail: ");
		scCad.nextLine();
		user.setEmail(scCad.nextLine());
		
		System.out.println("Telefone: ");
		scCad.nextByte();
		user.setTelefone(scCad.nextByte());
		
		System.out.println("Endereco: ");
		scCad.nextLine();
		user.setEndereco(scCad.nextLine());
		
		System.out.println("CPF: ");
		scCad.nextInt();
		user.setCpf(scCad.nextInt());
		
		
	}
}
