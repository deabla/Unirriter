package app;

public class AcessoRestaurante {

}
