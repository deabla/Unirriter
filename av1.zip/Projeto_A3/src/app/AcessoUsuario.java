package app;

import java.util.Scanner;

public class AcessoUsuario {

	public void MenuDoUsuario() {

		Scanner scUser = new Scanner(System.in);

		//tributo para opcao do menu do usuario
		int opUsuario;
		
		do {
			System.out.println("*** MENU DO USUARIO ***");
			System.out.println("1- Entrar");
			System.out.println("2- Criar Cadastro");
			System.out.println("0- Sair");
			opUsuario = scUser.nextInt();
			
			switch(opUsuario) {
			case 1:
				//opcao caso o usuario
				break;
				
			case 2: 
				//opcao para cadastrar usuario
				break;
			
			case 0:
				System.out.println("Opcao invalida!");
				break;
			}
		} while (opUsuario !=0);
	}
}
