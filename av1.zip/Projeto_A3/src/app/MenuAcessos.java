package app;

import java.util.Scanner;

public class MenuAcessos {

	public void MenuDeAcesso() {
		
		AcessoUsuario userAcess = new AcessoUsuario();
		Scanner sc = new Scanner(System.in);

		// Atributo para escolher a opcao do menu
		int opcao;

		do {
            System.out.println(" _____________________________________");
            System.out.println("|         Vergoin da Profission       |");
            System.out.println("|_____________________________________|");
            System.out.println("|                                     |");
            System.out.println("|  1- Acesso Usuario                  |");
            System.out.println("|  2- Acesso Restaurante              |");
            System.out.println("|  0- Sair                            |");
            System.out.println("|_____________________________________|");
            System.out.println("|       Digite a op��o desejada       |");
            opcao = sc.nextInt();
            System.out.println("|_____________________________________|");

            switch (opcao) {

                case 1:

                    int opcao2;
                    do {
                        System.out.println(" __________________________________________");
                        System.out.println("|            Sistema de clientes           |");
                        System.out.println("|__________________________________________|");
                        System.out.println("|                                          |");
                        System.out.println("| 1- Cadastro de cliente                   |");
                        System.out.println("| 2- Excluir cliente espec�fico            |");
                        System.out.println("| 3- Excluir todos os clientes             |");
                        System.out.println("| 4- Procurar cliente por CPF              |");
                        System.out.println("| 5- Consultar todos clientes do sistema   |");
                        System.out.println("| 0- Sair                                  |");
                        System.out.println("|__________________________________________|");
                        System.out.println("|         Digite a op��o desejada          |");
                        opcao2 = sc.nextInt();
                        System.out.println("|__________________________________________|");

                        switch (opcao2) {
                            case 1:
                                System.out.println(" _____________________________________");
                                System.out.println("|        Cadastro de clientes         |");
                                System.out.println("|_____________________________________|");
                                System.out.println("|                                     |");
                                System.out.println("| Digite seu nome:                    |");
                                sc.nextLine();
                                //CadastroUsuario.setNome(sc.nextLine());
                                System.out.println("| Digite seu E-mail:                  |");
                                sc.nextLine();
                                System.out.println("| Digite seu CPF:                     |");
                                sc.nextLine();
                                System.out.println("| Digite seu CEP:                     |");
                                sc.nextInt();
                                System.out.println("| Digite seu n�mero de telefone:      |");
                                sc.nextInt();
                                break;
                            case 2:
                                break;
                            case 3:
                                break;
                            case 4:
                                break;
                            case 5:
                                break;
                            case 0:
                                break;
                            default:

                        }

                    } while (opcao2 != 0);


            }

        } while (opcao != 0);

	}
}