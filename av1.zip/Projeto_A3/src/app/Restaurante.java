package app;

public class Restaurante {
	
	//definindo atributos
	private String nomeRestaurante;
	private String prato;
	private String preco;
	private String descricao;
	private String endereco;
	private int cep;
	private int cnpj;
	private int horarios;
	
	//encapsulamento
	public String getRestaurante() {
		return nomeRestaurante;
	}
	public void setRestaurante(String restaurante) {
		this.nomeRestaurante = restaurante;
	}
	public String getPrato() {
		return prato;
	}
	public void setPrato(String prato) {
		this.prato = prato;
	}
	public String getPreco() {
		return preco;
	}
	public void setPreco(String preco) {
		this.preco = preco;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public int getHorarios() {
		return horarios;
	}
	public void setHorarios(int horarios) {
		this.horarios = horarios;
	}
	public int getCep() {
		return cep;
	}
	public void setCep(int cep) {
		this.cep = cep;
	}
	public int getCnpj() {
		return cnpj;
	}
	public void setCnpj(int cnpj) {
		this.cnpj = cnpj;
	}

	@Override
	public String toString() {
		return "Restaurante \nRestaurante " + nomeRestaurante + "\nPrato: " + prato + "\nPreco:" + preco + "\nDescricao: "
				+ descricao + "\nEndereco: " + endereco + "CEP: " + cep + "\nCNPJ: " + cnpj + "\nHorarios: " + horarios;
	}
	
	
}
