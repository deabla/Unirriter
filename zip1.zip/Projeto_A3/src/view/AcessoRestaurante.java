package view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.CadastroPratos;
import model.CadastroRestaurante;
import model.Restaurante;


public class AcessoRestaurante {
	
	public void MenuRestaurante() {

		CadastroPratos cp = new CadastroPratos();
		MenuAcessos mn = new MenuAcessos();
		CadastroRestaurante cr = new CadastroRestaurante();
		Scanner scres = new Scanner(System.in);
		
		ArrayList<Restaurante> lista;


		int op;

		do {
			System.out.println(" __________________________________________");
			System.out.println("|            Sistema Restaurante           |");
			System.out.println("|__________________________________________|");
			System.out.println("|                                          |");
			System.out.println("| 1- Cadastrar Restaurante				   ");
			System.out.println("| 2- Login			          		       ");
			System.out.println("| 3- Voltar ao Menu principal              ");
			System.out.println("| 0- Sair                                  ");
			System.out.println("|__________________________________________|");
			System.out.println("|         Digite a opcao desejada          |");
			op = scres.nextInt();
			System.out.println("|__________________________________________|");

			switch (op) {
			case 1:
				cr.cadastrarRestaurante();
				break;

			case 2:
				//Login
				cr.mostrarRestaurantes();
				break;

			case 3:
				mn.MenuPrincipal();
				break;

			}
		} while (op != 0);
	}
}
