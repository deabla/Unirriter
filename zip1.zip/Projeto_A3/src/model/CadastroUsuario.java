package model;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CadastroUsuario {
	
	
	private ArrayList<Usuario> lista;
	// ArrayList
	
	Scanner scuser = new Scanner(System.in);
	Usuario userUm = new Usuario();
	int qntUser;
	public ArrayList<Usuario> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Usuario> lista) {
		this.lista = lista;
	}

	// adicionar usuario
	public void adicionarUser(Usuario u1) {
		this.lista.add(u1);
	}



	public void cadastrarUsuario() {

		// atributo para MenuUser

			System.out.println(" ______________________________________________ ");
			System.out.println("|               CADASTRAR USUARIO              |");
			System.out.println("|______________________________________________|");
			System.out.println("|                                              |");
			System.out.println("| Digite o seu nome:                           |");
			userUm.setNome(scuser.nextLine());
			System.out.println("| Digite seu E-mail:                           |");
			userUm.setEmail(scuser.nextLine());
			//Inserindo CPF - Validador de 11 digitos
			do {
				System.out.println("| Digite seu CPF:                              |");
				userUm.setCpf(scuser.nextLine());
				if (userUm.getCpf().length() < 11 || userUm.getCpf().length() > 11) {
					System.out.println("ERRO! CPF INVALIDO!");
				}
			} while (userUm.getCpf().length() < 11 || userUm.getCpf().length() > 11);
			
			System.out.println("| Digite seu Endereco:                         |");
			userUm.setEndereco(scuser.nextLine());
			//Inserindo telefone - validador de 9 digitos com DO e IF
			do {
			System.out.println("| Digite seu numero de telefone:               |");
				userUm.setTelefone(scuser.nextLine());
				if (userUm.getTelefone().length() < 9) {
					System.out.println("ERRO! TELEFONE INVALIDO!");
				}
			} while (userUm.getTelefone().length() < 9);
			System.out.println("\n");

			System.out.println("|        USUARIO CADASTRADO COM SUCESSO!       |");
			System.out.println("|______________________________________________|");

		}


int i = 0;

public void mostrarUsuarios() {

	for (int i = 0; i < qntUser; i++) {
		System.out.println("Usuario " + i);
		System.out.println("Nome: " + userUm.getNome());
		System.out.println("E-mail: " + userUm.getEmail());
		System.out.println("CPF: " + userUm.getCpf());
		System.out.println("Endereco: " + userUm.getEndereco());
		System.out.println("Telefone: " + userUm.getTelefone());
		System.out.println("\n");
	}
}
	public String salvarUsuario(){

			try {
				FileWriter fw = new FileWriter("Usuarios.txt");
				PrintWriter pw = new PrintWriter(fw);
				pw.println("Nome: " + userUm.getNome());
				pw.println("E-mail " + userUm.getEmail());
				pw.println("CPF: " + userUm.getCpf());
				pw.println("Endereco: " + userUm.getEndereco());
				pw.println("Telefone: " + userUm.getTelefone());
			} catch (IOException ex) {
				Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
			}
			return null;
	}

}
