package model;

import java.util.Scanner;
import java.util.ArrayList; // import the ArrayList class

public class CadastroRestaurante {
	
	
	// ArrayList
	
	private ArrayList<Restaurante> lista;
	Scanner scuser = new Scanner(System.in);
	Restaurante resum = new Restaurante();
	public ArrayList<Restaurante> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Restaurante> lista) {
		this.lista = lista;
	}

	// adicionar restaurante
	public void adicionarRes(Restaurante res1) {
		this.lista.add(res1);
	}

	Scanner scr = new Scanner(System.in);
	Restaurante rte = new Restaurante();
	CadastroPratos cp = new CadastroPratos();

	int qntRest;

	public void cadastrarRestaurante() {
		System.out.println(" _________________________________________________");
		System.out.println("|        	Cadastro de Restaurante    		      |");
		System.out.println("|_________________________________________________|");
		System.out.println("|                                     	          |");
		System.out.println("|Quantos restaurantes deseja cadastrar?			  ");
		qntRest = scr.nextInt();

		for (int i = 0; i < qntRest; i++) {
			System.out.println("|Nome do Restaurante:                         ");
			scr.nextLine();
			rte.setnomeRestaurante(scr.nextLine());

			cp.CadastrarPratos();

			System.out.println("|Endereco do restaurante:                     ");
			rte.setEndereco(scr.nextLine());

			System.out.println("|Horario de abertura:                         ");
			rte.setHorarioAbrir(scr.nextLine());

			System.out.println("|Horario de fechamento:                       ");
			rte.setHorarioFechar(scr.nextLine());

			System.out.println("***RESTAURANTE CADASTRADO COM SUCESSO!!!***");
		}
	}

	public void mostrarRestaurantes() {

		for (int i = 0; i < qntRest; i++) {

			System.out.println("Restaurante " + i);
			System.out.println("Nome: " + rte.getnomeRestaurante());
			System.out.println("Endereco: " + rte.getEndereco());
			System.out.println("Horario de abertura: " + rte.getHorarioAbrir());
			System.out.println("Horario de fechamento: " + rte.getHorarioFechar());
			System.out.println("CARDAPIO: ");
			cp.MostrarPratos();
			System.out.println("\n");
		}
	}
}
