package model;

public class MostrarPedidos {
	
	CadastroPratos cp = new CadastroPratos();
	CadastroRestaurante cr = new CadastroRestaurante();
	
	public void fazerPedido() {
		
		System.out.println("Escolha um restaurante: ");
		cr.mostrarRestaurantes();
		
		
	}
}
