package lists;

import java.util.ArrayList;

import app.Restaurante;

public class ListaRestaurante {

	private ArrayList<Restaurante> res = new ArrayList<Restaurante>();

	public ArrayList<Restaurante> getRestaurante() {
		return res;
	}

	public void setRestaurante(ArrayList<Restaurante> res) {
		this.res = res;
	}
	
	public void adicionarRestaurante(Restaurante r1) {
		this.res.add(r1);
	}
	
}
