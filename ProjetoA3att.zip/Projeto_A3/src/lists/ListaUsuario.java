package lists;

import java.util.ArrayList;

import app.Usuario;

public class ListaUsuario {
	
	private ArrayList <Usuario> listauser;

	public ArrayList<Usuario> getListauser() {
		return listauser;
	}

	public void setListauser(ArrayList<Usuario> listauser) {
		this.listauser = listauser;
	}
	
	
	public void adicionarUsuario(Usuario u1) {
		this.listauser.add(u1);
	}

	@Override
	public String toString() {
		return "Lista de Usuario {" + "lista:" + this.listauser + "}";
	}


}
 
