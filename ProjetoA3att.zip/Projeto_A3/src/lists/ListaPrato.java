package lists;

import java.util.ArrayList;

import app.Prato;

public class ListaPrato {

	private ArrayList<Prato> listprato = new ArrayList<Prato>();

	public ArrayList<Prato> getListprato() {
		return listprato;
	}

	public void setListprato(ArrayList<Prato> listprato) {
		this.listprato = listprato;
	}

	public void adicionarPrato(Prato p1) {

		this.listprato.add(p1);
	}
}
