package app;

import java.util.ArrayList;
import java.util.Scanner;

import lists.ListaUsuario;

public class AcessoUsuario {

	public void MenuDoUsuario() {

		MenuAcessos menu = new MenuAcessos();
		ListaUsuario u1 = new ListaUsuario();
		Scanner scUser = new Scanner(System.in);

		int opcao2;

		do {

			System.out.println(" __________________________________________");
			System.out.println("|            Sistema de Usuario            |");
			System.out.println("|__________________________________________|");
			System.out.println("|                                          |");
			System.out.println("| 1- Cadastrar				               |");
			System.out.println("| 2- Login			          		       |");
			System.out.println("| 3- Voltar pro Menu Principal			   |");
			System.out.println("| 0- Sair                                  |");
			System.out.println("|__________________________________________|");
			System.out.println("|         Digite a opcao desejada          |");
			opcao2 = scUser.nextInt();
			System.out.println("|__________________________________________|");

			switch (opcao2) {
			case 1:
				Usuario user1 = new Usuario();
				System.out.println(" _____________________________________");
				System.out.println("|        Cadastro de Usuario          |");
				System.out.println("|_____________________________________|");
				System.out.println("|                                     |");
				System.out.println("| Digite seu nome:                    |");
				scUser.nextLine();
				user1.setNome(scUser.nextLine());

				System.out.println("| Digite seu E-mail:                  |");
				user1.setEmail(scUser.nextLine());
				
				do {
					System.out.println("| Digite seu CPF:                 |");
					user1.setCpf(scUser.nextLine());
				  if (user1.getCpf().length() < 11) {
						System.out.println("ERRO! CPF INVÁLIDO!");
					}
				} while (user1.getCpf().length() < 11);
				
				System.out.println("| Digite seu Endereco:                |");
				user1.setEndereco(scUser.nextLine());

				do {
					System.out.println("| Digite seu numero de telefone:  |");
					user1.setTelefone(scUser.nextLine());
					if (user1.getTelefone().length() < 9) {
						System.out.println("ERRO! CPF INVÁLIDO!");
					}
				} while (user1.getTelefone().length() < 9);
				
				System.out.println("| USUARIO CADASTRADO COM SUCESSO!     |");
				System.out.println("|_____________________________________|");
				u1.adicionarUsuario(user1);

				break;

			case 2: // entrar cad feito / MAPS
				break;
				
			case 3:
				menu.MenuPrincipal();
				break; 
				
			case 0:
				System.out.println("Sistema Encerrado.");
				break;

			}
		} while (opcao2 != 0);
	}
}